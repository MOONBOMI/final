package com.example.mapper_oracle;

import com.example.domain.LoansAccountVO;

public interface LoansAccountMapper {

	public void loansaccountinsert(LoansAccountVO lvo);
}
