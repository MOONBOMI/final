package com.example.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CrawlingController {
	@RequestMapping("company.json")
	@ResponseBody
	public HashMap<String, String> companyJson(String number) throws Exception {
		HashMap<String, String> array = new HashMap<>();
		System.setProperty("webdriver.chrome.driver", "d:/spring/chromedriver.exe"); // �뱶�씪誘몃쾭 �젙�쓽
		ChromeOptions options= new ChromeOptions();
		options.addArguments("headless");
		WebDriver driver = new ChromeDriver(options);
		driver.get("https://teht.hometax.go.kr/websquare/websquare.html?w2xPath=/ui/ab/a/a/UTEABAAA13.xml");
		

		
		WebElement insert= driver.findElement(By.xpath("//*[@id='bsno']"));
		insert.sendKeys(number);
		
		
		WebElement btnSearch = driver.findElement(By.xpath("//*[@id='trigger5']"));
		btnSearch.click();
		
		WebDriverWait wait = new WebDriverWait(driver, 6);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='grid2_cell_0_1']")));
		
		WebElement result = driver.findElement(By.xpath("//*[@id='grid2_cell_0_1']"));
		array.put("result", result.getText());
		System.out.println(result.getText());
		
		
		driver.quit();
		return array;
	}
	
	@RequestMapping("company")
	public void company() {
		
	}
}
